====================================================================================================

Add-on resource pack, created by Pankakes_81. Majority of textures (if included) are from Potterworld.
Credit to them for providing textures and models and this README.

====================================================================================================

Droobledore LLC - PotterworldMC Resource Pack

for the Minecraft server:

play.potterworldmc.com

====================================================================================================

Thank you for playing on the PotterworldMC server! This texture pack is only intended to be used

on the server. Please refrain from redistributing, retexturing, or taking models without permission.

====================================================================================================
-Credits-

3d models, textures, animations, and rigging all done by Droobledore LLC:

- Droobledore

The BASE textures for this resource pack are all from John Smith Legacy credits below:

http://www.johnsmithlegacy.co.uk/credits.php

Thanks to all of the People who helped with the John Smith Legacy pack:

- JohnSmith
- JimStoneCraft
- Glowstontium
- Greenhawk837
- iTpyn
- Zica
- Arkindal
- Freakscar
- JohnLemon
- Leenhaart
- flying sheep
- RedSolar (for the old Sheep Colours)
- Lazdude2012
- PwnyBrony32
- Codiferus17
- _DRYBONES_
- xXTerra_BranfordXx
- Nehaw55
- EchoZeero
- WaterTipper
- Necron 1992
- Soulburner
- Brice47
- JonnnLeee (for the wonderful flowers)
- Dweller_Benthos

And all the people in the Minecraft Forum community.

Kahr for MCPatcher
sp614x for Optifine

and of course Mojang for the game that is Minecraft.
https://minecraft.net/